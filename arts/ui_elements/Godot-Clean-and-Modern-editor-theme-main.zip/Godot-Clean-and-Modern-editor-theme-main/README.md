# Godot-Clean-and-Modern-editor-theme

UI theme for Godot 4 that gives the editor clean look and reduces visual clutter.

To install, extract `Clean and Modern.tres` anywhere, then when editor is open, go to `Editor/Editor settings.../Theme/Custom Theme` and point to the file.
![UI theme](https://github.com/Rytelier/Godot-Clean-and-Modern-editor-theme/assets/45795134/7f84a366-bdb6-459e-a3f4-149691a53f99)
